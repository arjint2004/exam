<div class="footer_wrapper">
    <div class="footer_menu">
        <br> <br>
        <span style="color:#999; font-size:14px; margin-top:10px;">&copy; <?=date('Y');?> Nama Perusahaan.</span>
    </div>
</div>
</body>
<html>