<?php $this->load->view('admin/header');?>
<?php $this->load->view('admin/'.$page);?>
<div class="clear"></div>
<?php $this->load->view('footer');?>