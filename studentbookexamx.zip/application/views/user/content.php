<?php $this->load->view('user/user_header');?>
<?php $this->load->view('user/'.$page);?>
<?php $this->load->view('footer');?>