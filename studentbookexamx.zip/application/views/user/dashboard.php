<div class="mainholder">
<div class="usercontent ui-corner-all">
<table width="900px" class="dashboard">
<tbody><tr>
<td><a href="<?=base_url();?>users/exams"><img src="<?=base_url();?>assets/images/exam.jpg" ></a></td>
<td><a href="<?=base_url();?>users/profile"><img src="<?=base_url();?>assets/images/user.png" ></a></td>
<td><a href="<?=base_url();?>users/view_results"><img src="<?=base_url();?>assets/images/test.png" ></a></td>
</tr>
<tr>
<td>Ujian</td><td>Edit Profil</td><td>Lihat hasil Ujian</td>
</tr>
</tbody></table>
</div></div>